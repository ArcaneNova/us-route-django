from django.apps import AppConfig


class FuelRouteConfig(AppConfig):
    name = 'api'
